const lang="en";const L=(e,v)=>e;
const PAGES=[["HomePage.html","Home","Trang chủ"],["learn.html","Why mechanical","Vì sao dùng phím cơ"],["switches.html","Switches","Switch"],["layouts.html","Layouts","Bố cục"],["keycaps.html","Keycaps","Keycap"],["gallery.html","Gallery"],["builder.html","Setup Lab","Thử ghép"],["quiz.html","Quiz","Trắc nghiệm"]];
const here=location.pathname.split("/").pop()||"HomePage.html";
const $=s=>document.querySelector(s);
$("#nav").innerHTML=`<nav class="navbar navbar-expand-lg navbar-dark sticky-top"><div class="container"><a class="navbar-brand fw-bold" href="HomePage.html">⌨ Lách Cách</a><button class="navbar-toggler" data-bs-toggle="collapse" data-bs-target="#m" aria-label="Menu"><span class="navbar-toggler-icon"></span></button><div id="m" class="collapse navbar-collapse"><ul class="navbar-nav ms-auto">${PAGES.map(([h,l,v])=>`<li class="nav-item"><a class="nav-link ${h==here?"active":""}" href="${h}">${L(l,v)}</a></li>`).join("")}</ul></div></div></nav>`;
$("#foot").innerHTML=`<footer><div class="container"><div class="row g-4"><div class="col-md-6"><strong>Lách Cách</strong><p class="small">Learn mechanical keyboards, then choose. Prototype for CSCU9X5. Specs and prices are examples.</p></div><div class="col-md-6"><strong>Support</strong><p class="small mb-1">${"Free beginner guides"}</p><a href="https://www.caniusevia.com" target="_blank" rel="noopener">VIA guide</a> · <a href="https://qmk.fm" target="_blank" rel="noopener">QMK guide</a><div class="mt-3"><a class="btn btn-sm btn-ink" href="quiz.html">${"Take the quiz"}</a></div></div></div></div></footer>`;

/* sound */
let ac,tone=700;
function click(){ac=ac||new (window.AudioContext||window.webkitAudioContext)();const t=ac.currentTime;[0,tone==2200?.04:null].forEach(d=>{if(d===null)return;const o=ac.createOscillator(),g=ac.createGain();o.type=tone<400?"sine":"square";o.frequency.value=tone;g.gain.setValueAtTime(.08,t+d);g.gain.exponentialRampToValueAtTime(.001,t+d+.06);o.connect(g).connect(ac.destination);o.start(t+d);o.stop(t+d+.07)})}

/* data */
const SW=[
["Cherry MX Red","linear",45,"Quiet, smooth","Smooth press with no bump. Light and fast, popular for gaming."],
["Gateron Yellow","linear",50,"Quiet, buttery","Slightly heavier linear that many people find very smooth."],
["Cherry MX Black","linear",60,"Quiet, deep","A heavy linear. Good if you often press keys by accident."],
["Cherry MX Brown","tactile",55,"Medium","A small bump tells you the key has registered. Good all-rounder for typing."],
["Holy Panda style","tactile",67,"Medium, thocky","A strong, rounded bump that typists love."],
["Boba U4T","tactile",62,"Medium","A big, soft bump with a satisfying feel."],
["Cherry MX Blue","clicky",60,"Loud click","A sharp click and a bump. Loud, so best used alone."],
["Kailh Box White","clicky",55,"Loud, crisp","A crisp click with a shorter travel feel."],
["Kailh Box Jade","clicky",65,"Very loud","A heavy click for people who love the sound."]];
const LY=[
["60%",61,"Smallest","No arrow keys, no function row","Travel, tiny desks"],
["65%",68,"Small","Arrow keys, no function row","Students, everyday use"],
["75%",84,"Compact","Function row and arrows, tightly packed","Programmers, all-round"],
["TKL (80%)",87,"Medium","Full layout minus the number pad","Gamers, office"],
["96%",100,"Large","Number pad squeezed in","Spreadsheets, coding"],
["Full-size",104,"Largest","Everything, with a gap before the number pad","Data entry, desk setups"]];
const KC=[
["Cherry","PBT","#1b2438","Low, sculpted rows and a classic sound.","Cherry profile"],
["OEM","ABS","#e8505b","The standard on most keyboards. Slightly taller than Cherry.","OEM profile"],
["SA","ABS","#f2c14e","Tall and curved with a retro typewriter look and deep sound.","SA profile"],
["XDA","PBT","#a9c5b0","Flat and uniform so all rows feel the same.","XDA profile"],
["MT3","PBT","#7d5ba6","Deep dish for a smooth, thocky feel.","MT3 profile"],
["Low profile","ABS","#4d8fcb","Short keys for flat laptop-style typing and travel.","Low profile"]];

/* switches page */
if($("#sw")){let f="all",max=70;const HH={linear:"l",tactile:"t",clicky:"c"}[location.hash.slice(1)];if(HH){f=location.hash.slice(1);$("#"+HH).checked=true}const draw=()=>{const l=SW.filter(s=>(f=="all"||s[1]==f)&&s[2]<=max);$("#swc").textContent=l.length+" switches";$("#sw").innerHTML=l.length?l.map(s=>`<div class="col-md-6 col-lg-4"><div class="tile"><span class="pill ${s[1]}">${s[1]}</span><h3 class="h5 mt-2">${s[0]}</h3><p class="mb-1 small">${s[4]}</p><p class="small mb-1">Actuation force: <b>${s[2]} g</b></p><div class="bar mb-2"><i style="width:${s[2]/70*100}%"></i></div><p class="small mb-2">Sound: ${s[3]}</p><button class="btn btn-sm btn-ink" data-t="${s[1]}" data-n="${s[0]}">Hear a click</button></div></div>`).join(""):`<p class="note">No switch matches. Raise the maximum force or choose "All".</p>`};
document.querySelectorAll("[name=type]").forEach(r=>r.onchange=()=>{f=r.value;draw()});
$("#force").oninput=e=>{max=+e.target.value;$("#fv").textContent=max+" g";draw()};
const MD=new bootstrap.Modal("#sv"),ST={linear:"#d63f4b",tactile:"#3d7a5f",clicky:"#3b5bdb"},
CAP={linear:[["Press down: smooth all the way, no bump.","Nhấn xuống: mượt suốt hành trình, không nấc."],["Sound: deep and soft.","Âm thanh: trầm và êm."],["Feel: quick and light, easy for gaming and fast typing.","Cảm giác: nhanh và nhẹ, hợp chơi game và gõ nhanh."]],
tactile:[["Press down: a small bump tells you the key registered.","Nhấn xuống: một nấc nhỏ cho biết phím đã được ghi nhận."],["Sound: medium and a little bouncy.","Âm thanh: vừa phải, hơi nảy."],["Feel: balanced, good for writing and coding.","Cảm giác: cân bằng, hợp viết lách và lập trình."]],
clicky:[["Press down: a bump plus a sharp click.","Nhấn xuống: một nấc kèm tiếng click sắc."],["Sound: loud and crisp.","Âm thanh: to và giòn."],["Feel: very clear feedback, but loud in shared rooms.","Cảm giác: phản hồi rất rõ, nhưng ồn ở phòng chung."]]};
let tm=null,ty="linear",i=0,playing=false;const N=8;
function swSound(k){ac=ac||new (window.AudioContext||window.webkitAudioContext)();const t=ac.currentTime;
const P={linear:[[400,1,.09,1.6,0],[200,1,.08,1.2,.07]],tactile:[[900,2,.05,1.2,0],[450,1,.09,1.4,.05],[200,1,.08,1.1,.1]],clicky:[[3200,6,.03,1.8,0],[1800,3,.05,1.4,.03],[450,1,.09,1.2,.08],[200,1,.08,1,.12]]}[k];
P.forEach(([f,q,d,g,at])=>{const n=ac.sampleRate*d|0,b=ac.createBuffer(1,n,ac.sampleRate),c=b.getChannelData(0);for(let j=0;j<n;j++)c[j]=(Math.random()*2-1)*(1-j/n)**2;const s=ac.createBufferSource(),fl=ac.createBiquadFilter(),gn=ac.createGain();s.buffer=b;fl.type="bandpass";fl.frequency.value=f;fl.Q.value=q;gn.gain.value=g;s.connect(fl);fl.connect(gn);gn.connect(ac.destination);s.start(t+at)})}
const stop=()=>{clearInterval(tm);playing=false;$("#svb").textContent=i>=N?"Replay":"Play"};
const step=()=>{const k=document.querySelectorAll("#svk .key")[i];k.classList.add("down");$("#svst").style.transform="translateY(22px)";$("#svsp").style.transform="scaleY(.6)";try{swSound(ty)}catch(e){}
setTimeout(()=>{k.classList.remove("down");$("#svst").style.transform="";$("#svsp").style.transform=""},180);i++;$("#svp").style.width=i/N*100+"%";$("#svc").textContent=L(...CAP[ty][Math.min(2,Math.floor(i/3))]);if(i>=N)stop()};
const play=()=>{if(i>=N){i=0;$("#svp").style.width="0"}clearInterval(tm);playing=true;$("#svb").textContent="Pause";step();tm=setInterval(step,520)};
$("#svb").onclick=()=>playing?stop():play();
$("#sv").addEventListener("hidden.bs.modal",()=>{i=0;stop();$("#svv").pause()});
$("#sw").onclick=e=>{const b=e.target.closest("[data-t]");if(!b)return;ty=b.dataset.t;i=0;stop();$("#svt").textContent=b.dataset.n+" · "+ty;$("#svsc").setAttribute("fill",ST[ty]);
$("#svk").innerHTML=[..."LACHCACH"].map(c=>`<span class="key">${c}</span>`).join("");$("#svp").style.width="0";$("#svc").textContent="";
$("#svn").textContent="Simulated demo: the sound is synthesized in your browser and the animation is illustrative, not a recording of this exact switch.";
const v=$("#svv");v.classList.add("d-none");$("#svsim").classList.remove("d-none");$("#svctl").classList.remove("d-none");
v.onloadeddata=()=>{stop();v.classList.remove("d-none");$("#svsim").classList.add("d-none");$("#svctl").classList.add("d-none")};v.src="assets/video/"+ty+".mp4";MD.show();play()};draw()}

/* layouts page */
if($("#ly")){const sel=new Set();let f="all";const draw=()=>{$("#ly").innerHTML=LY.filter(l=>f=="all"||l[2]==f).map(l=>`<div class="col-md-6 col-lg-4"><div class="tile"><h3 class="h5">${l[0]} <small class="text-muted">${l[1]} keys</small></h3><p class="small mb-1">${l[3]}</p><p class="small">Good for: ${l[4]}</p><div class="bar mb-3"><i style="width:${l[1]}%"></i></div><input type="checkbox" class="btn-check" id="c${l[1]}" ${sel.has(l[0])?"checked":""} data-n="${l[0]}"><label class="btn btn-outline-dark btn-sm" for="c${l[1]}">Compare</label></div></div>`).join("")};
const tab=()=>{const r=LY.filter(l=>sel.has(l[0]));$("#cmp").innerHTML=r.length<2?`<p class="note">Tick Compare on two or three layouts to see them side by side.</p>`:`<div class="table-responsive"><table class="table table-bordered bg-white"><thead><tr><th>Layout</th><th>Keys</th><th>Size</th><th>Includes</th><th>Good for</th></tr></thead><tbody>${r.map(l=>`<tr><td><b>${l[0]}</b></td><td>${l[1]}</td><td>${l[2]}</td><td>${l[3]}</td><td>${l[4]}</td></tr>`).join("")}</tbody></table></div>`};
$("#ly").onchange=e=>{const n=e.target.dataset.n;if(!n)return;if(e.target.checked){if(sel.size>=3){e.target.checked=false;$("#lm").textContent="You can compare up to 3 layouts. Untick one first.";return}sel.add(n)}else sel.delete(n);$("#lm").textContent="";tab()};
document.querySelectorAll("[name=size]").forEach(r=>r.onchange=()=>{f=r.value;draw()});draw();tab()}

/* keycaps page */
if($("#kc")){let m="all";const draw=()=>{$("#kc").innerHTML=KC.map((k,i)=>({k,i})).filter(o=>m=="all"||o.k[1]==m).map(({k,i})=>`<div class="col-6 col-md-4"><button class="cap" style="background:${k[2]};color:${k[2]=="#f2c14e"||k[2]=="#a9c5b0"?"#1b2438":"#fff"}" data-i="${i}" aria-label="Preview ${k[0]} keycaps">${k[0]}</button><p class="small mt-3 mb-0"><b>${k[1]}</b> – ${k[4]}</p></div>`).join("")};
document.querySelectorAll("[name=mat]").forEach(r=>r.onchange=()=>{m=r.value;draw()});
$("#kc").onclick=e=>{const b=e.target.closest(".cap");if(!b)return;const k=KC[b.dataset.i];$("#mt").textContent=k[0]+" – "+k[1];$("#mb").textContent=k[3];$("#mc").style.background=k[2];$("#mc").style.color=(k[2]=="#f2c14e"||k[2]=="#a9c5b0")?"#1b2438":"#fff";$("#mc").textContent=k[0];new bootstrap.Modal("#pv").show()};draw()}

/* home hero keys */
if($("#hero")){const L=[..."LÁCHCÁCH"];$("#hero").innerHTML=L.map((c,i)=>`<button class="key ${i==0?"red":i==4?"yel":""}" data-c="${c}">${c}</button>`).join("");
$("#hero").onclick=e=>{if(e.target.dataset.c)click()};
document.querySelectorAll("[name=snd]").forEach(r=>r.onchange=()=>tone=+r.value);
let n=0;$("#typer").addEventListener("keydown",()=>{click();n++;$("#cnt").textContent=n+" keys pressed"})}

/* quiz */
if($("#q")){const Q=[
[["What is your budget?","Ngân sách của bạn?"],[["Under $60","Dưới 1,5 triệu",{c:2,g:1}],["$60 – $120","1,5 – 3 triệu",{t:2,g:1}],["Over $120","Trên 3 triệu",{p:2,t:1}]]],
[["How much noise is okay?","Bạn chấp nhận ồn đến mức nào?"],[["Silent please","Càng yên tĩnh càng tốt",{c:2,p:1}],["Some noise is fine","Hơi ồn cũng được",{t:2,g:1}],["Loud is fun","Ồn cũng vui",{g:2,t:1}]]],
[["What do you mostly do?","Bạn chủ yếu làm gì?"],[["Gaming","Chơi game",{g:3}],["Writing and coding","Viết và code",{t:2,p:1}],["Everything, plus travel","Đủ thứ, hay di chuyển",{c:2}]]],
[["Do you carry it around?","Bạn có mang theo không?"],[["Every day","Mỗi ngày",{c:3}],["Sometimes","Thỉnh thoảng",{t:1,p:1}],["Never","Không bao giờ",{g:1,p:2}]]]];
const R={c:[["Compact travel board","Bàn phím nhỏ gọn mang theo"],["65% layout, quiet linear or silent switches, wireless.","Layout 65%, switch linear êm hoặc silent, không dây."],"Keychron K6, Akko 3068"],
g:[["Fast gaming board","Bàn phím chơi game phản hồi nhanh"],["TKL or 75%, light linear switches, wired for low delay.","TKL hoặc 75%, switch linear nhẹ, có dây để ít trễ."],"Ducky One 3 TKL, Logitech G Pro"],
t:[["Everyday typing board","Bàn phím gõ hằng ngày"],["75% layout, tactile switches, balanced sound.","Layout 75%, switch tactile, âm thanh cân bằng."],"Keychron V1, Epomaker TH80"],
p:[["Premium desk board","Bàn phím cao cấp để bàn"],["75% gasket-mounted, tactile or smooth linear, hot-swap.","75% gasket mount, tactile hoặc linear mượt, hot-swap."],"Keychron Q1, Wuque Studio Mode"]};
let i=0,sc,ans=[];const top=o=>Object.keys(o).sort((a,b)=>o[b]-o[a])[0];
const go=()=>{i=0;ans=[];sc={c:0,g:0,t:0,p:0};show()};
const show=()=>{if(i>=Q.length){const r=R[top(sc)];$("#pb").style.width="100%";
$("#q").innerHTML=`<h2 class="h3">${"We suggest"}: ${L(...r[0])}</h2><p>${L(...r[1])}</p><h3 class="h6">${"Why this result"}</h3><ul>${ans.map((a,k)=>`<li>${L(...Q[k][0])} <b>${L(Q[k][1][a][0],Q[k][1][a][1])}</b> → ${"points to"} ${L(...R[top(Q[k][1][a][2])][0])}</li>`).join("")}</ul><p class="note">${"Examples"}: ${r[2]}. ${"Prices change, so check a shop first."}</p><a class="btn btn-ink me-2 mb-2" href="switches.html">${"Try these switches"}</a><a class="btn btn-ink me-2 mb-2" href="layouts.html">${"Compare layouts"}</a><button class="btn btn-outline-dark mb-2" id="re">${"Start again"}</button>`;$("#re").onclick=go;return}
$("#pb").style.width=i/Q.length*100+"%";
$("#q").innerHTML=`<p class="small">${"Question"} ${i+1}/${Q.length}</p><h2 class="h4 mb-3">${L(...Q[i][0])}</h2>${Q[i][1].map((o,j)=>`<button class="btn btn-outline-dark d-block w-100 text-start mb-2" data-j="${j}">${L(o[0],o[1])}</button>`).join("")}${i?`<button class="btn btn-link" id="bk">${"Back"}</button>`:""}`;
const b=$("#bk");if(b)b.onclick=()=>{i--;ans.pop();sc={c:0,g:0,t:0,p:0};ans.forEach((a,k)=>Object.entries(Q[k][1][a][2]).forEach(([x,v])=>sc[x]+=v));show()}};
$("#q").onclick=e=>{const j=e.target.dataset.j;if(j===undefined)return;ans[i]=+j;Object.entries(Q[i][1][j][2]).forEach(([x,v])=>sc[x]+=v);i++;show()};go()}
function snd(k){const c=$("#cap");if(c)c.textContent={thock:"Deep, soft sound (thock)",clack:"Sharp, high sound (clack)",silent:"Almost no sound (silent)"}[k];ac=ac||new (window.AudioContext||window.webkitAudioContext)();const t=ac.currentTime,P={thock:[[170,"triangle",.18,.14]],clack:[[1900,"square",.07,.05],[3100,"square",.04,.04]],silent:[[110,"sine",.05,.06]]}[k];P.forEach(([f,ty,v,d])=>{const o=ac.createOscillator(),g=ac.createGain();o.type=ty;o.frequency.value=f;g.gain.setValueAtTime(v,t);g.gain.exponentialRampToValueAtTime(.001,t+d);o.connect(g).connect(ac.destination);o.start(t);o.stop(t+d+.01)})}
let kind="thock";
/* 3D hero board */
if($("#board")){const R=[[1,1,1,1,1,1,1,1,1,1,1,1,1,2],[1.5,1,1,1,1,1,1,1,1,1,1,1,1,1.5],[1.75,1,1,1,1,1,1,1,1,1,1,1,2.25],[2.25,1,1,1,1,1,1,1,1,1,1,2.75],[1.25,1.25,1.25,6.25,1.25,1.25,1.25,1.25]];
const B=$("#board");B.innerHTML=R.map((r,ri)=>`<div class="krow">${r.map((w,i)=>`<div class="k3 ${ri==0&&i==r.length-1?"red":w>1&&ri!=4?"yel":""}" style="width:${w*44-4}px"></div>`).join("")}</div>`).join("");
let rx=55,rz=-25,auto=!matchMedia("(prefers-reduced-motion:reduce)").matches,d=null;const ap=()=>B.style.transform=`rotateX(${rx}deg) rotateZ(${rz}deg)`;
const S=$("#stage");S.onpointerdown=e=>{d=[e.clientX,e.clientY];auto=false};window.onpointerup=()=>d=null;
S.onpointermove=e=>{if(!d)return;rz+=(e.clientX-d[0])*.4;rx=Math.max(0,Math.min(85,rx-(e.clientY-d[1])*.3));d=[e.clientX,e.clientY];ap()};
(function f(){if(auto){rz+=.15;ap()}requestAnimationFrame(f)})();ap();
B.onclick=e=>{const k=e.target.closest(".k3");if(!k)return;k.classList.add("dn");snd(kind);setTimeout(()=>k.classList.remove("dn"),120)};
document.querySelectorAll("[data-v]").forEach(b=>b.onclick=()=>{[rx,rz]=b.dataset.v.split(",").map(Number);auto=false;ap()})}
/* sound test */
if($("#pad")){$("#pad").innerHTML=[..."QWERASDF"].map(c=>`<button class="key">${c}</button>`).join("");$("#pad").onclick=e=>{if(e.target.classList.contains("key"))snd(kind)};
document.querySelectorAll("[name=k]").forEach(r=>r.onchange=()=>{kind=r.value;snd(kind)});$("#typer2").addEventListener("keydown",()=>snd(kind))}
/* scrollytelling */
if($("#steps")){const L=document.querySelectorAll(".lay");const io=new IntersectionObserver(es=>es.forEach(e=>{if(e.isIntersecting)L.forEach((l,i)=>l.classList.toggle("on",i==+e.target.dataset.i))}),{rootMargin:"-45% 0px -45% 0px"});document.querySelectorAll(".step").forEach(s=>io.observe(s))}
/* setup lab */
if($("#opts")){const O={layout:[["60%",61,"Smallest, saves desk space but has no arrow keys.","Nhỏ nhất, tiết kiệm bàn nhưng không có phím mũi tên."],["75%",84,"Compact but keeps arrows and function keys.","Gọn nhưng vẫn có phím mũi tên và phím chức năng."],["TKL",87,"Full layout without the number pad.","Đủ phím nhưng không có cụm số."],["Full-size",104,"Everything, including the number pad.","Đầy đủ, kể cả cụm số."]],
case:[["Graphite","#2b2f3a","Dark and hides fingerprints.","Tối, ít lộ dấu vân tay."],["Silver","#aeb6c4","Bright and clean look.","Sáng, gọn gàng."],["Navy","#1f3a6b","Calm and professional.","Điềm tĩnh, chuyên nghiệp."],["Sage","#7ea58b","Soft and friendly.","Nhẹ nhàng, thân thiện."]],
caps:[["PBT Cherry","#e8ecf5","Durable and textured, deeper sound.","Bền, nhám, âm trầm hơn."],["PBT XDA","#a9c5b0","Flat and even feel on every row.","Phẳng, các hàng phím đều nhau."],["ABS SA","#f2c14e","Smooth and tall, may get shiny over time.","Trơn và cao, lâu ngày có thể bóng."]],
sw:[["Linear","thock","Smooth, no bump, quiet.","Mượt, không nấc, êm."],["Tactile","thock","Small bump so you feel each press.","Có nấc nhẹ, cảm nhận từng lần bấm."],["Clicky","clack","Bump plus a loud click.","Có nấc và tiếng click lớn."]]};
const G=[["layout","Layout","Layout"],["case","Case colour","Màu vỏ"],["caps","Keycaps","Keycap"],["sw","Switch","Switch"]],sel={layout:1,case:0,caps:0,sw:1};
$("#opts").innerHTML=G.map(([k,t,v])=>`<fieldset class="mb-4"><legend class="h6">${L(t,v)}</legend>${O[k].map((o,i)=>`<input type="radio" class="btn-check" name="${k}" id="${k}${i}" value="${i}" ${sel[k]==i?"checked":""}><label class="btn btn-outline-dark me-2 mb-2" for="${k}${i}">${o[0]}</label>`).join("")}</fieldset>`).join("");
const pre=()=>{const l=O.layout[sel.layout],c=O.case[sel.case],k=O.caps[sel.caps];$("#pv2").style.background=c[1];$("#pv2").style.width=({61:15,84:16,87:18,104:22}[l[1]]*22+24)+"px";$("#pv2").innerHTML=Array.from({length:l[1]},()=>`<i style="background:${k[1]}"></i>`).join("");$("#sum").innerHTML=G.map(([g,t,v])=>{const o=O[g][sel[g]];return `<li><b>${L(t,v)}: ${o[0]}</b> – ${L(o[2],o[3])}</li>`}).join("")};
$("#opts").onchange=e=>{sel[e.target.name]=+e.target.value;pre()};$("#hear").onclick=()=>snd(O.sw[sel.sw][1]);pre()}
document.documentElement.lang=lang;
